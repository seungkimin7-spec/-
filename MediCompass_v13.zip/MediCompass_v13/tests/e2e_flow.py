import asyncio, json, sys
from playwright.async_api import async_playwright
URL='file:///home/claude/medi/web/index.html'
res=[]
def chk(name,ok,info=''):
    res.append((name,bool(ok),info)); print(('PASS' if ok else 'FAIL'),name,info)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        for vp,label in (({'width':390,'height':844},'phone'),({'width':820,'height':1180},'ipad')):
            pg=await b.new_page(viewport=vp); errs=[]
            pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:asyncio.ensure_future(d.accept()))
            await pg.goto(URL)
            # manual entry path
            html=await pg.content()
            btn=[t for t in ('직접 입력','직접 입력하기') if t in html]
            chk(label+': start screen renders',await pg.locator('h1').count()>0)
            # go to review via manual button
            m=pg.get_by_text('직접 입력').first
            await m.click()
            chk(label+': review screen',await pg.locator('#meds').count()==1)
            await pg.fill('#meds','테스트약 10mg'); await pg.check('#confirmMeds'); await pg.click('#next')
            chk(label+': survey q1',await pg.locator('#ansNum').count()==1)
            await pg.fill('#ansNum','72'); await pg.click('#ansOk')           # age
            await pg.select_option('#ansSel','서울'); await pg.click('#ansOk') # region
            await pg.click('.opt[data-v=national]')                             # insurance
            await pg.click('.opt[data-v=low]')                                  # income
            await pg.click('.opt[data-v=unknown]')                              # condition unknown
            await pg.click('.opt[data-v=high]')                                 # expense
            chk(label+': care question shown for 72',await pg.locator('#qtitle').inner_text()=='일상생활에서 다른 사람의 도움이 필요한가요?')
            await pg.click('.opt[data-v=yes]'); await pg.click('.opt[data-v=alone]')
            chk(label+': results screen',await pg.locator('h1').inner_text()=='④ 의료복지 추천 결과')
            txt=await pg.locator('#screen').inner_text()
            for n in ('본인부담상한제','건강보험 산정특례','재난적의료비 지원사업','의료급여','노인맞춤돌봄서비스','노인장기요양보험','기초연금','지자체 의료비 지원사업'):
                chk(label+': scheme '+n,n in txt)
            chk(label+': 3 level labels used',all(k in txt for k in ('주요 조건 충족 가능','추가 확인 필요')))
            chk(label+': no "guarantee" wording','수급 자격 판정이 아닙니다' in txt)
            # level expectations (age72, national, low, severe unknown, high expense, care yes, alone)
            lv=await pg.evaluate("state.list.map(x=>[x.s.id,x.level])")
            d=dict(lv); chk(label+': pension possible',d['pension']=='possible',str(d)); chk(label+': care possible',d['care']=='possible'); chk(label+': medical (national+low)',d['medical']=='possible'); chk(label+': special check',d['special']=='check'); chk(label+': longterm possible',d['longterm']=='possible')
            # detail
            await pg.click('[data-d=pension]')
            chk(label+': detail screen','기초연금' in await pg.locator('h1').inner_text())
            chk(label+': verified note','확인일 2026-11-17' in await pg.locator('#screen').inner_text())
            await pg.click('#dback'); chk(label+': back to list',await pg.locator('.card').count()>=8)
            # no horizontal scroll
            ov=await pg.evaluate("document.documentElement.scrollWidth>window.innerWidth+1"); chk(label+': no horizontal scroll',not ov)
            # touch target >=44
            small=await pg.evaluate("[...document.querySelectorAll('button,.btn')].filter(e=>e.offsetParent&&e.getBoundingClientRect().height<44).length"); chk(label+': touch targets >=44px',small==0,str(small))
            # export download
            async with pg.expect_download() as dl: await pg.click('#export')
            dd=await dl.value; path=await dd.path(); body=open(path,encoding='utf-8').read(); chk(label+': txt export',('기초연금' in body) and ('자격 판정이 아닌' in body))
            # wipe
            await pg.click('#wipe')
            chk(label+': wipe resets',await pg.evaluate("state.step===0&&Object.keys(state.answers).length===0&&!state.fields.meds&&state.detail===null"))
            # unknown path + age<60 hides care
            await pg.get_by_text('직접 입력').first.click(); await pg.fill('#meds','x'); await pg.check('#confirmMeds'); await pg.click('#next')
            await pg.fill('#ansNum','40'); await pg.click('#ansOk'); await pg.click('.opt[data-v=unknown]')
            for _ in range(5): 
                if await pg.locator('#qtitle').count(): await pg.click('.opt[data-v=unknown]')
            chk(label+': all-unknown reaches results',await pg.locator('h1').inner_text()=='④ 의료복지 추천 결과')
            lv=dict(await pg.evaluate("state.list.map(x=>[x.s.id,x.level])")); chk(label+': age40 pension unlikely',lv['pension']=='unlikely',str(lv))
            chk(label+': no JS errors',not errs,str(errs))
            await pg.close()
        await b.close()
asyncio.run(main())
f=[r for r in res if not r[1]]; print('TOTAL',len(res),'FAIL',len(f)); json.dump(res,open('/home/claude/medi/tests/e2e_flow_result.json','w'),ensure_ascii=False)
